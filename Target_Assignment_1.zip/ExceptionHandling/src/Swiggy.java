import java.util.ArrayList;
import java.util.Scanner;

public class Swiggy {
    static ArrayList<Integer>ZipCode=new ArrayList<Integer>(){
        {
            add(232);add(236);add(245);add(249);add(251);add(257);add(262);add(266);add(268);add(274);add(275);add(279);
            add(280);add(285);add(288);add(299);add(300);
        }
    };
    public static void DeliveryValidation(int zipcode) throws Exception{
        try{
            boolean available=ZipCode.contains(zipcode);
            if(available){
                System.out.println("Food Delivery Available In Your Area!!!");
            }
            else{
                throw new Exception("Delivery Not Available In Your Area!!!");
            }
        }
        catch (Exception e){
            System.out.println(e);
        }
    }

    public static void main(String [] args) throws Exception {
        Scanner sc=new Scanner(System.in);
        int zip_code=sc.nextInt();
        DeliveryValidation(zip_code);
    }
}
