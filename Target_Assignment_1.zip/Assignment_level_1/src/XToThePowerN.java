import java.util.Scanner;
public class XToThePowerN {
    public static void main(String [] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number");
        int x= sc.nextInt();
        System.out.println("Enter the power to "+x);
        int n= sc.nextInt();
        int ans=1;
        for(int i=1;i<=n;i++){
            ans = ans*x;

        }
        System.out.println(x+"^"+n+" is : "+ans);

    }
}
