import java.util.Scanner;

public class Sequence4 {

    public static void main(String [] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number");
        int n= sc.nextInt();
        int n1=1,n2=4,n3=7;
        System.out.print(n1+" "+n2+" "+n3+" ");
        for(int i=4;i<=n;i++){
            int n4=n1+n2+n3;
            System.out.print(n4+" ");
            n1=n2;
            n2=n3;
            n3=n4;
        }
    }
}
