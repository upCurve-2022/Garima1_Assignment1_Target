import java.util.Scanner;

public class Sum {
    int n;
    int sum=0;
    public void OddSum(){
        sum=0;
        for(int i=0;i<=n;i++){
            if(!(i%2==0)){
                sum+=i;
            }
        }
    }

    public void EvenSum(){
        sum=0;
        for(int i=0;i<=n;i++){
            if((i%2==0)){
                sum+=i;
            }
        }
    }
    public void show(){
        System.out.println("Sum : "+sum);
    }
    public void get(){
        Scanner sc=new Scanner(System.in);
        this.n=sc.nextInt();
    }
    public static void main(String [] args){
        Sum s=new Sum();
        System.out.println("Enter a number upto which Sum is to be done");
        s.get();
        System.out.println("Odd Sum :");
        s.OddSum();
        s.show();
        System.out.println("Even Sum :");
        s.EvenSum();
        s.show();
    }
}
