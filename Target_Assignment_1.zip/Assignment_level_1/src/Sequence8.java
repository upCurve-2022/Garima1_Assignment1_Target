import java.util.Scanner;
public class Sequence8 {
    public static void main(String [] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number");
        int n= sc.nextInt();
        int n0=0,n1=1;
        System.out.print(n1+" ");
        for(int i=1;i<=n;i++){
            int n2=n0+n1;
            System.out.print(n2+" ");
            n0=n1;
            n1=n2;
        }
    }
}
