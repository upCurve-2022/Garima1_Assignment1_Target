import java.util.Scanner;

import static java.lang.Math.pow;

public class Amstrong {
    public static void main(String [] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a number");
        int n=sc.nextInt();
        int temp=n,sum=0;
        while(temp!=0){
            int lastdigit=temp%10;
            sum+=pow(lastdigit,3);
            temp/=10;
        }
        if(sum==n)
            System.out.println("A pallindrom");
        else
            System.out.println("Not a pallindrom");
    }
}
