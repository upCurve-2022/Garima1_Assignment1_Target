import java.util.Scanner;

import static java.lang.Math.pow;

public class BinarytoDecimal {
    public static void main(String [] args){
        int i=0,ans=0;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a decimal number");
        int n=sc.nextInt();
        while(n!=0){
        int lastdigit = n%10;
        ans+=lastdigit*pow(2,i);
        i++;
        n/=10;
        }
        System.out.println(ans);
    }
}