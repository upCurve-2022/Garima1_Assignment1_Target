import java.util.Scanner;

public class SeparateDouble {
    public static void main(String [] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a double type number");
        double num=sc.nextDouble();
        int whole =(int) num;
        double fraction= (num%1);
        System.out.println("whole : "+whole+" ,fraction : "+fraction);
    }
}
