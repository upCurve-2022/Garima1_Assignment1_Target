import java.util.Scanner;

public class SimpleInterest {
    public static void main(String [] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter principle amount,rate, time(in months only) respectively");
        int p=sc.nextInt();
        int r=sc.nextInt();
        float t=sc.nextInt();
        t=t/12;
        float si=(p*r*t)/100;
        System.out.println("Simple interest on principle amount, "+p+" , is :: "+si);
        System.out.println("Ammount : "+ ( p+si ));
    }
}
