import java.util.Scanner;

public class Pallindrom {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a string ");
        String str=sc.next();
        int mid=str.length()/2;
        String left= str.substring(0, mid);
        String right= str.substring(mid+1);
        if(str.length()%2==0)
        {
            right= str.substring(mid);
        }
        //reverse string
        String revLeft="";
        for(int i=0;i<left.length();i++){
            char ch=left.charAt(i);
            revLeft=ch+revLeft;
        }
        if(revLeft.equals(right))
            System.out.println("Yes");
        else
            System.out.println("No");
    }
}
