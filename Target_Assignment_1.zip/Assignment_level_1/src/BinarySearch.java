import java.util.Scanner;

public class BinarySearch {
    public static void main(String [] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter length of array");
        int n=sc.nextInt();
        int flag=0;
        int [] arr=new int[n];
        System.out.println("Enter Sorted array");
        for(int i=0;i<n;i++)
            arr[i]=sc.nextInt();
        System.out.println("Enter key to search");
        int key=sc.nextInt();
        int low=0,high=n-1;
        while(low<=high){
            int mid=(low+high)/2;
            if(arr[mid]==key) {
                flag=1;
                System.out.println("Key found at position " + (mid+1));
                break;
            }
            else if(arr[mid]<key)
                low=mid+1;
            else
                high=mid-1;
        }
        if(flag==0)
            System.out.println("Key not found ");
    }
}
