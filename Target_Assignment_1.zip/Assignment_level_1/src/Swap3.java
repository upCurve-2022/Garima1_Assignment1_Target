import java.util.Scanner;
public class Swap3{
    int num1,num2,num3;
    Swap3(int num1,int num2,int num3){
        this.num1=num1;
        this.num2=num2;
        this.num3=num3;
    }
    void Show(){
        System.out.println("num1 : "+num1+" ,num2 : "+num2+" ,num3 : "+num3);
    }
    void swap(){
        num1=num1+num2+num3;

        num2=num1-(num2+num3);
        num3=num1-(num2+num3);
        num1=num1-(num2+num3);

    }
    public  static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter 3 numbers");
        int a =sc.nextInt();
        int b =sc.nextInt();
        int c =sc.nextInt();
        Swap3 obj= new Swap3(a,b,c);

        System.out.println("Before swap : ");
        obj.Show();
        obj.swap();
        System.out.println("After swap : ");
        obj.Show();
    }

}
