import java.util.Scanner;
public class Sequence9 {
    public static void main(String [] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number");
        int n= sc.nextInt();
        int s1=1,s2=-2;
        for(int i=1;i<=n;i++){
            if(!(i%2==0))
            {
                System.out.print(s1+" ");
                s1+=3;
            }
            else
            {
                System.out.print(s2+" ");
                s2-=4;
            }
        }
    }
}
