import java.util.Scanner;

public class Largest_SecondLargest {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter 3 numbers");
        int num1 = sc.nextInt();
        int num2 = sc.nextInt();
        int num3 = sc.nextInt();
        //All are equal
        if(num1==num2&&num1==num3){

            System.out.println("All numbers are equal");
        }
        //num1 is largest
        else if(num1>num2 && num1>num3){
            if(num2>num3)   System.out.println(num1+" is the largest and "+num2 +" is the second largest number");
            else System.out.println(num1+" is the largest and "+num3 +" is the second largest number");
        }

        //num2 is largest
        else if(num2>num1 && num2>num3){
            if(num1>num3)   System.out.println(num2+" is the largest and "+num1 +" is the second largest number");
            else System.out.println(num2+" is the largest and "+num3 +" is the second largest number");
        }

        //num3 is the largest
        else{
            if(num1>num2)   System.out.println(num3+" is the largest and "+num1 +" is the second largest number");
            else System.out.println(num3+" is the largest and "+num2 +" is the second largest number");
        }

    }
}
