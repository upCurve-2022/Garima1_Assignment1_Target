import java.util.Scanner;

public class ArithmaticExpression {
    public static void main(String [] args){
        System.out.println("Give values to the variables present in expression : ");
        System.out.println("a+b+(c*d)-(e/f)");
        Scanner sc=new Scanner(System.in);
        int a=sc.nextInt();
        int b=sc.nextInt();
        int c=sc.nextInt();
        int d=sc.nextInt();
        int e=sc.nextInt();
        int f=sc.nextInt();
        c=c*d;
        e=e/f;
        a=a+b;
        int ans=a+c-e;
        System.out.println("Ans for the expression \'a+b+(c*d)-(e/f)\' is : "+ans);

    }
}
