import java.util.Scanner;

import static java.lang.Math.pow;

public class Sequence5 {
    public static void main(String [] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number");
        int n= sc.nextInt();
        for(int i=1;i<=n;i++){
            System.out.print((int)pow(i,2)+" ");
        }
    }
}
