import java.util.Scanner;
public class Swap2 {
    int num1;
    int num2;
    Swap2(int num1,int num2){
        this.num1=num1;
        this.num2=num2;
    }
    void swap(){
        int temp=num1;
        num1=num2;
        num2=temp;
    }
    void Show(){
        System.out.println("num1 : "+num1+" num2 : "+num2);
    }
    public static void main(String [] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter values into 2 numbers");
        int a=sc.nextInt();
        int b=sc.nextInt();
        Swap2 obj=new Swap2(a,b);
        System.out.println("Before Swap : ");
        obj.Show();
        obj.swap();
        System.out.println("After Swap : ");
        obj.Show();

    }

}
