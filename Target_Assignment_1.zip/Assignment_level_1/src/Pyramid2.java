import java.awt.*;
import java.util.Scanner;

public class Pyramid2 {
    public static void main(String [] args){
        int n=5, k,i,j;
        for(i=1;i<=n;i++){

            for(j=1;j<=n-i;j++)
            {
                System.out.print(" ");
            }
            for(k=1;k<=i;k++){
                System.out.print((" *"));
            }
            System.out.print("\n");
        }
    }
}
