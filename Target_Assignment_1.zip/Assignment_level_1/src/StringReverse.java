import javax.swing.plaf.synth.SynthTextAreaUI;
import java.util.Scanner;
public class StringReverse {
    public static void main(String [] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string");
        String str= sc.next();
        //Approach 1
        String newStr="";
        for(int i=0;i<str.length();i++){
            char ch=str.charAt(i);
            newStr=ch+newStr;
        }
        System.out.println("Reversed String using Approach 1: "+newStr );
        //Approach 2
        char[] chars=str.toCharArray();
        int start=0,last=str.length()-1;
        while(start<=last){
            char temp=chars[start];
            chars[start]=chars[last];
            chars[last]=temp;
            start++;
            last--;
        }
        str=String.valueOf(chars);
        System.out.println("Reversed String Using Approach 2 : "+str );

    }
}