import java.awt.desktop.SystemEventListener;
import java.util.Scanner;

import static java.lang.Math.pow;

public class Sequence6 {
    public static void main(String [] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number");
        int n= sc.nextInt();
        for(int i=1;i<=n;i++){
            int temp1=3*(int)(pow(i-1,2));
            int temp2= (int) (3+pow(-1,i))/2;
            System.out.print(temp1+temp2+"  ");
        }
    }
}
