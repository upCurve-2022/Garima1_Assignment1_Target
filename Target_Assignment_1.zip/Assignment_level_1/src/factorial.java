import java.util.Scanner;

public class factorial{
    int fact(int n){
        if(n==1)return 1;
        else
            return n*fact(n-1);
    }
    public static void main(String [] args){
        factorial f=new factorial();
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a number");
        int n= sc.nextInt();
        System.out.println(f.fact(n));
    }
}