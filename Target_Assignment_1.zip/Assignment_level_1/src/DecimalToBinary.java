import java.util.Scanner;

public class DecimalToBinary {
    //14
    //1110
    public static void main(String [] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a decimal number");
        int dec=sc.nextInt();
        int i=0;
        int [] rem=new int [32];

        while(dec>0){
            rem[i]=dec%2;
            dec=dec/2;
            i++;
        }
        while(i!=0){
            System.out.print(rem[i-1]+" ");
            i--;
        }
    }
}
