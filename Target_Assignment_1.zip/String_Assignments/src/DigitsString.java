import java.util.Scanner;

public class DigitsString {
    public static void main(String [] args){
        String str;
        int flag=0;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a string");
        str=sc.next();
        for(int i=0;i<str.length();i++){
            if(str.charAt(i)>='0'&&str.charAt(i)<='9') {
                flag = 1;

            }
            else {
                flag = 0;
                break;
            }
        }
        if(flag==1)
            System.out.println("The string contains only DIGITS");
        else
            System.out.println("The string does not contains only DIGITS");
    }

}
