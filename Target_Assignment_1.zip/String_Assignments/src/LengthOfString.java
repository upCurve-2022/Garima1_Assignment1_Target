import java.util.Scanner;

public class LengthOfString {
    public static void main(String [] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a string");
        String str=sc.next();
        //Approach 1
        System.out.println("String length using length function : "+str.length());
        //Approach 2
        char [] arr=str.toCharArray();
        int count=0;
        while(str.isEmpty()){
            str=str.substring(count);
            count++;
        }
        System.out.println("String length using Approach 2 : "+count);
    }
}
