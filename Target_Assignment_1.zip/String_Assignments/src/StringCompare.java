import java.util.Scanner;

public class StringCompare {
    public static void main(String [] args){

        String str1="Target";
        String str2="Target";
        //method 1

        if(str1.equals(str2))
            System.out.println("Strings are equal using \'equals()\' method (Method 1)");
        if(str1.equalsIgnoreCase(str2))
            System.out.println("Strings are equal using \'equalsIgnoreCase()\' method (Method 2)");

        System.out.println("Strings are equal using \'compareTo()\' method (Method 3)"+str1.compareTo(str2));

        if(str1==str2)
            System.out.println("Strings are equal using \'==\' operator (Method 4)");
    }
}
