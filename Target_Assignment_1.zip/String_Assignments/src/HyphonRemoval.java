import java.awt.*;
import java.util.ArrayList;

public class HyphonRemoval {
    public String str="134-10/556 A-block,Manyaat Tech-Park";
    public static void main(String [] args){


        HyphonRemoval obj = new HyphonRemoval();
        System.out.println("Main String  :  "+obj.str);
        ArrayList<Integer> indices=new ArrayList<Integer>();
        int ind=obj.str.indexOf("-");
        indices.add(ind);
        while(ind>=0){
            ind = obj.str.indexOf("-", ind + 1);
            indices.add(ind);
        }
//        System.out.println(indices);

        for(int i=0;i<indices.size();i++){
            //Testing for in-between...
            if (indices.get(i)> 0 &&indices.get(i) < obj.str.length() - 1) {
//                System.out.println("inside \t\t\t\t obj.index > 0 && obj.index < obj.str.length() - 1");
                char prev=obj.str.charAt((indices.get(i))-1);
                char next=obj.str.charAt((indices.get(i))+1);
//                System.out.println("previous character of hyphon : "+prev);
//                System.out.println("next character of hyphon : "+next);
                if (Character.isDigit(prev)&& Character.isDigit(next)) {
                    obj.str = obj.str.substring(0, indices.get(i)) + "" + obj.str.substring(indices.get(i) + 1);
//                    System.out.println("STRING str : "+obj.str);
                }
            }
        }


        System.out.println("Final String  :  "+obj.str);
    }
}
