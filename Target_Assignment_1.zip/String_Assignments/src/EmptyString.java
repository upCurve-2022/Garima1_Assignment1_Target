import java.util.Scanner;

public class EmptyString {
    public static void main(String [] args){
        Scanner sc=new Scanner(System.in);
        String str=sc.nextLine();
        //Approach1
        if(str.length()==0)
            System.out.println("String is empty using Approach 1");
        if(str.isEmpty())
            System.out.println("String is empty using Approach 2");

    }
}
