public class ImmutableString {
    public static void main(String [] args){
        String s="Target";
        s.concat("Upcurve");
        System.out.println("Strings are immutable thus after concat the s is unchanged ");
        System.out.println("s : "+s);
        s=s.concat("upcurve");
        System.out.println("Since we have explicitly changed the refference of s therefore now 's' refers to \"Target Upcurve\" ");
        System.out.println("s : "+s);
    }
}
