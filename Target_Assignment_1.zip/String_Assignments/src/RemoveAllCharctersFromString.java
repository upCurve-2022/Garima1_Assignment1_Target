import java.util.Locale;
import java.util.Scanner;

public class RemoveAllCharctersFromString {
    public static void main(String [] args) {
        String str;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string");
        str = sc.nextLine();
        String str1 = str;
        System.out.println("Enter a character which is to be removed from the string");
        String ch = sc.next();
        ch = ch.toLowerCase(Locale.ROOT);
        str = str.replaceAll(ch, "");
        ch = ch.toUpperCase(Locale.ROOT);
        str = str.replaceAll(ch, "");
        System.out.println("New string = " + str);

    }
}



