public class Replace {
    public static void main(String [] args){
        String str="I am always ready to learn although i do not always like being taught";
        System.out.println("Main String : "+str+"\n");
        //Approach 1
        String temp=str.replace('a','$');
        System.out.println("New String Using Approach 1 :\n"+temp);
        //Approach 2
        char [] arr=str.toCharArray();
        for(int i=0;i<str.length();i++){
            if(arr[i]=='a')
                arr[i]='$';
        }
        System.out.println("\nNew String Using Approach 2:");
        for(int i=0;i<str.length();i++){
           System.out.print(arr[i]);
        }

    }
}
