import java.util.Scanner;

public class DuplicateCharacters {
    public static void main(String [] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a strings");
        String str=sc.next();
        char [] arr=str.toCharArray();
        for(int i=0;i<str.length();i++){
            for(int j=i+1;j<str.length();j++){
                if(arr[i]==arr[j]){
                    System.out.print(arr[i]+" ");
                }
            }
        }
    }
}
