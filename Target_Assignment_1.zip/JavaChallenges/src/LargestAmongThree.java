import java.util.Scanner;

public class LargestAmongThree {
    public static void main(String [] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter 3 numbers");
        double d1=sc.nextDouble(),d2=sc.nextDouble(),d3= sc.nextDouble();
        double greatest=(d1>d2)?(d1>d3?d1:d3):(d2>d3?d2:d3);
        System.out.println("greatest  = "+greatest);
    }
}
