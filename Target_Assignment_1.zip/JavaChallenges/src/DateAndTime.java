import java.time.Clock;
import java.time.LocalDateTime;
import java.util.Date;

public class DateAndTime {
    public static void main(String [] args){
        //Method  1
        Date date=new Date();
        System.out.println("Today's date & time (Using Date Class) is : "+date);
        //Method 2
        System.out.println("Today's date & time (Using LocalDateTime method) is : "+LocalDateTime.now());
        //Method 3
        System.out.println("Today's date & time (Using Clock Class) is : "+Clock.systemUTC().instant());
    }
}
