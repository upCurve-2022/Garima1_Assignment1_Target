import java.util.Scanner;

public class CylinderVolume {
    public static void main(String [] args){
        double pi=3.14,r,h;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter radius of the cylinder");
        r=sc.nextDouble();
        System.out.println("Enter height of the cylinder");
        h= sc.nextDouble();
        double rSquare=r*r;
        System.out.println("Volume of the cylinder is : "+ pi*rSquare*h);
    }
}
