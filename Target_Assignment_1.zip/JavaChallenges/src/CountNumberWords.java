import java.util.Scanner;

public class CountNumberWords {
    public static void main(String [] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a strings");
        String str = sc.nextLine();
        int count=0,num=0;
        char [] arr=str.toCharArray();
        for(int i=0;i<str.length();i++){
            if(arr[i]==' '||((arr[0]!=' ')&&(i==0))){
                count++;
            }
            if(arr[i]>='0'&& arr[i]<='9')
            {
                num++;
                i=i+1;
                while(i<arr.length && arr[i]!=' ' ){
                    i++;
                }
                i=i-1;
            }
        }
        System.out.println("Number of words : "+count);
        System.out.println("Number(Numeric) words : "+num);
    }
}
