import java.util.Scanner;

public class StringContains {
    public static void main(String [] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter 2 strings");
        String str1=sc.next();
        String str2=sc.next();
        boolean isContain=str1.contains(str2);
        if(isContain)
            System.out.println("String1 contains String2");
        else
            System.out.println("String1 does not contains String2");
    }
}
