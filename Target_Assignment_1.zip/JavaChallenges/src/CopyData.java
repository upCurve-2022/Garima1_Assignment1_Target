import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyData {
    public static void main(String [] args) throws IOException {
        FileInputStream r=new FileInputStream("D:\\Projects\\test1.txt");
        FileOutputStream w=new FileOutputStream("D:\\Projects\\test2.txt");
        int i;
        while((i=r.read())!=-1){
            w.write((char)i);
        }
        System.out.println("Daata cpied successfully");
    }
}
