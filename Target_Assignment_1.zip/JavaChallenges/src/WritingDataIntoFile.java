import java.io.*;
public class WritingDataIntoFile {
    public static void main(String [] args) {
        try{
            FileOutputStream fout=new FileOutputStream("D:\\Projects\\JavaText.txt");
            String s="Hello world";
            byte[] b=s.getBytes();
            fout.write(b);
            fout.close();
            System.out.println("Data Written successfully");
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
}
