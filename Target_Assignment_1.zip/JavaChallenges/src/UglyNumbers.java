import java.util.Scanner;

public class UglyNumbers {
    static int maxDivide(int num,int val){
        while(num%val==0){
            num/=val;
        }
        return num;
    }
    static boolean checkUgly(int num){
        num=maxDivide(num,2);
        num=maxDivide(num,3);
        num=maxDivide(num,5);
        return num == 1;
    }
    static int finUgly(int Nnum){
        int num=1,count=1;
        while(Nnum>count){
            num++;
            if(checkUgly(num))
                count++;
        }
        return num;
    }
    public static void main(String [] args){
        System.out.println("Enter a positive number");
        Scanner sc = new Scanner(System.in);
        int num=sc.nextInt();
        System.out.println("The "+num+"th ugly number is : "+finUgly(num));
    }
}
