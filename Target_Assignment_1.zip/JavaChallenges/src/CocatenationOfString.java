import java.util.Scanner;

public class CocatenationOfString {
    public static void main(String [] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter two strings");
        String str1 = sc.next();
        String str2 = sc.next();
        //Approach 1
        System.out.println("Concatenated using \'+\' operator : "+str1+str2);
        //Approach 2
        String str=str1.concat(str2);
        System.out.println("Concatenated using \'concat()\' : "+str);
        //Approach 3
        str=String.format("%s%s",str1,str2);
        System.out.println("Concatenated using \'format()\' : "+str);
        //Approach 4
        str=String.join("",str1,str2);
        System.out.println("Concatenated using \'join()\' : "+str);
        //Approach 5
        StringBuilder s1= new StringBuilder(str1);
        StringBuilder s2= new StringBuilder(str2);
        StringBuilder s=s1.append(s2);
        System.out.println("Concatenation using \'StringBuilder append()\' :"+s);
    }
}
