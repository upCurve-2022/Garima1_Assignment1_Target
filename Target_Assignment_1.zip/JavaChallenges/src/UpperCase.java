import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Locale;
import java.util.Scanner;

public class UpperCase {
    public static void main(String [] args){
        Scanner sc=new Scanner(System.in);
        String str=sc.nextLine();
        //Approach 1
        System.out.println("Uppercase String Using Approach 1 :\n"+str.toUpperCase(Locale.ROOT));
        //Approach 2
        char [] arr=str.toCharArray();
        for(int i=0;i<str.length();i++){
            if(arr[i]>='a'&&arr[i]<='z'){
                char ch=arr[i];
                int replace=(int)ch-32;
                arr[i]=(char)replace;
            }
        }
        System.out.println("\nUppercase String Using Approach 2 : ");
        for(int i=0;i<str.length();i++)
            System.out.print(arr[i]);
    }
}
