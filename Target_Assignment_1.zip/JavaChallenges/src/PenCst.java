public class PenCst {
    public static void main(String [] args){
        double pen_cost=50;
        double pen_dis_per=12;
        double pen_dis_amt=(pen_cost*pen_dis_per)/100;
        double pen_selling_price=pen_cost-pen_dis_amt;
        System.out.println("Pen's Discount amount : "+pen_dis_amt);
        System.out.println("Pen's selling price : "+pen_selling_price);
    }
}
