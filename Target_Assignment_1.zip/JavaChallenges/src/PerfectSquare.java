import java.util.Scanner;

public class PerfectSquare {
    static boolean apprroach2(double num){
        for(int i=1;i*i<=num;i++){
            if((num%i==0) && (num/i==i))
                return true;
        }

        return false;

    }
    public static void main(String [] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a number");
        double num=sc.nextDouble();
        //Approach 1
        System.out.println("\n\t\t\tApproach 1\n");
        double SQRT=Math.sqrt(num);
        if(SQRT-Math.floor(SQRT)==0)
            System.out.println("Perfect square");
        else
            System.out.println("Not A Perfect square");
        //Approach 2
        System.out.println("\n\t\t\tApproach 2\n");
        if(apprroach2(num))
            System.out.println("Perfect square");
        else
            System.out.println("Not A Perfect square");
    }
}
